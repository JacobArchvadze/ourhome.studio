
let userAccept = confirm('Are you ready to see the designs?');




if(userAccept){
    let userInputValue =prompt('enter your username');
    if (userInputValue){
    if(userInputValue === 'username')
    { 
        alert('Hello dear username')}
    else{
        alert('Please press F5')
    }
    
    }

}

else{
    alert('Go away <3')
}
    
    
function myFunction(x) {
    x.classList.toggle("change");
  }